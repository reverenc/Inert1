package com.example.inertloginmodule.models

data class DefaultResponse(val error: Boolean, val message:String)