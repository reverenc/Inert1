package com.example.inertloginmodule.models

data class LoginResponse(val status: Boolean, val msg:String)
/*
data class LoginResponse(val error: Boolean, val message:String, val user: User)*/
